package com.silentcobra.scdolphy.analyzer

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.silentcobra.scdolphy.data.CaptureStore
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold
import java.io.File

private fun shareExport(context: android.content.Context, content: String, fileName: String, mime: String) {
    val dir = File(context.getExternalFilesDir(null), "exports").apply { mkdirs() }
    val file = File(dir, fileName)
    file.writeText(content)
    val uri = FileProvider.getUriForFile(context, "com.silentcobra.scdolphy.fileprovider", file)
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    context.startActivity(Intent.createChooser(intent, "تصدير"))
}

@Composable
fun ProtocolAnalyzerScreen() {
    val context = LocalContext.current
    val records by CaptureStore.records.collectAsState()

    ToolScaffold(title = "محلل البروتوكولات") {
        Text(
            "يعرض هذا القسم الحزم الملتقطة تلقائيًا من وحدتي BLE وNFC أثناء استخدامهما (عرض Hex).",
            color = DolphyText
        )
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = {
                shareExport(context, CaptureStore.toCsv(), "scdolphy_capture.csv", "text/csv")
            }) { Text("تصدير CSV") }
            Button(onClick = {
                shareExport(context, CaptureStore.toJson(), "scdolphy_capture.json", "application/json")
            }) { Text("تصدير JSON") }
            OutlinedButton(onClick = { CaptureStore.clear() }) { Text("مسح") }
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text("عدد السجلات: ${records.size}", color = DolphyText)
        Spacer(modifier = Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(records.reversed()) { record ->
                Surface(shape = RoundedCornerShape(10.dp), color = DolphySurface) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text("${record.timeString} · ${record.source} · ${record.label}", color = DolphyText)
                        Text(
                            record.hex.ifEmpty { "(لا توجد بيانات خام)" },
                            color = DolphyText,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}
