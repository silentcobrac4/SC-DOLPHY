package com.silentcobra.scdolphy.smartmap

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.silentcobra.scdolphy.lan.LanDevice
import com.silentcobra.scdolphy.lan.getLocalIpAndPrefix
import com.silentcobra.scdolphy.lan.scanSubnet
import com.silentcobra.scdolphy.ui.DolphyCyan
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin

private fun colorFor(type: DeviceType): Color = when (type) {
    DeviceType.ROUTER -> Color(0xFF2FD2FF)
    DeviceType.CAMERA -> Color(0xFFFF5C5C)
    DeviceType.IOT -> Color(0xFF8CFF6B)
    DeviceType.MOBILE_OR_PC -> Color(0xFFFFD166)
    DeviceType.UNKNOWN -> Color(0xFF7E95AE)
}

@Composable
fun SmartMapScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val devices = remember { mutableStateMapOf<String, LanDevice>() }
    var scanning by remember { mutableStateOf(false) }
    var newDeviceAlerts by remember { mutableStateOf(listOf<String>()) }

    ToolScaffold(title = "الماسح الشبكي الذكي") {
        val localInfo = getLocalIpAndPrefix(context)
        if (localInfo == null) {
            Text("اتصل بشبكة Wi-Fi أولاً.", color = DolphyText)
            return@ToolScaffold
        }

        Button(
            enabled = !scanning,
            onClick = {
                devices.clear()
                scanning = true
                scope.launch {
                    val known = getKnownMacs(context)
                    val seenNow = mutableSetOf<String>()
                    scanSubnet(localInfo.first) { device ->
                        devices[device.ip] = device
                        device.mac?.let { mac ->
                            seenNow.add(mac)
                            if (mac !in known) {
                                notifyNewDevice(context, device.ip, device.vendor)
                                newDeviceAlerts = newDeviceAlerts + "${device.ip} (${device.vendor ?: "غير معروف"})"
                            }
                        }
                    }
                    saveKnownMacs(context, known + seenNow)
                    scanning = false
                }
            }
        ) {
            Text(if (scanning) "جاري الفحص..." else "فحص الشبكة")
        }

        Spacer(modifier = Modifier.height(12.dp))

        val deviceList = devices.values.toList()
        Canvas(modifier = Modifier.fillMaxWidth().height(260.dp)) {
            val center = Offset(size.width / 2, size.height / 2)
            val radius = minOf(size.width, size.height) / 2.6f

            // center node = this device
            drawCircle(color = DolphyCyan, radius = 18f, center = center)

            deviceList.forEachIndexed { index, device ->
                val angle = (2 * Math.PI * index / maxOf(deviceList.size, 1))
                val pos = Offset(
                    center.x + (radius * cos(angle)).toFloat(),
                    center.y + (radius * sin(angle)).toFloat()
                )
                drawLine(color = Color(0x552FD2FF), start = center, end = pos, strokeWidth = 2f)
                drawCircle(color = colorFor(classifyDevice(device)), radius = 12f, center = pos)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))
        if (newDeviceAlerts.isNotEmpty()) {
            Surface(shape = RoundedCornerShape(10.dp), color = DolphySurface) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("أجهزة جديدة اكتُشفت في هذا الفحص:", color = DolphyText)
                    newDeviceAlerts.forEach { Text("• $it", color = DolphyText) }
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(deviceList.sortedBy { it.ip }) { d ->
                val type = classifyDevice(d)
                Surface(shape = RoundedCornerShape(12.dp), color = DolphySurface) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(d.ip, color = DolphyText)
                            Text(d.vendor ?: d.mac ?: "", color = DolphyText)
                        }
                        Text(type.displayName(), color = colorFor(type))
                    }
                }
            }
        }
    }
}
