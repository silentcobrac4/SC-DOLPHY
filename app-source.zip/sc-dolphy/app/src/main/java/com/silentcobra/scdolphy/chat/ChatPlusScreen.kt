package com.silentcobra.scdolphy.chat

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.silentcobra.scdolphy.ble.hasBlePermissions
import com.silentcobra.scdolphy.ble.requiredBlePermissions
import com.silentcobra.scdolphy.ui.DolphyBlue
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold

@Composable
fun ChatPlusScreen() {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(hasBlePermissions(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        hasPermission = r.values.all { it }
    }

    var passphrase by remember { mutableStateOf("") }
    var role by remember { mutableStateOf<String?>(null) } // "host" | "join"
    var host by remember { mutableStateOf<ChatHost?>(null) }
    var client by remember { mutableStateOf<ChatClient?>(null) }
    var input by remember { mutableStateOf("") }

    val messages = when {
        host != null -> host!!.messages.collectAsState().value
        client != null -> client!!.messages.collectAsState().value
        else -> emptyList()
    }
    val status = when {
        host != null -> host!!.statusText.collectAsState().value
        client != null -> client!!.statusText.collectAsState().value
        else -> ""
    }

    ToolScaffold(title = "Dolphy Chat+") {
        if (!hasPermission) {
            Button(onClick = { launcher.launch(requiredBlePermissions()) }) { Text("منح الأذونات") }
            return@ToolScaffold
        }

        if (role == null) {
            Text(
                "دردشة محلية عبر BLE بتشفير AES-256-GCM من طرف إلى طرف. اتفق مع الطرف الآخر على نفس كلمة السر مسبقًا (مثلاً بقولها شفهيًا).",
                color = DolphyText
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = passphrase,
                onValueChange = { passphrase = it },
                label = { Text("كلمة السر المشتركة") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    enabled = passphrase.isNotBlank(),
                    onClick = {
                        val key = CryptoUtils.deriveKey(passphrase)
                        val h = ChatHost(context, key)
                        h.start()
                        host = h
                        role = "host"
                    }
                ) { Text("استضافة (Host)") }
                Button(
                    enabled = passphrase.isNotBlank(),
                    onClick = {
                        val key = CryptoUtils.deriveKey(passphrase)
                        val c = ChatClient(context, key)
                        c.start()
                        client = c
                        role = "join"
                    }
                ) { Text("انضمام (Join)") }
            }
            return@ToolScaffold
        }

        Text("الحالة: $status", color = DolphyText)
        Spacer(modifier = Modifier.height(10.dp))
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (msg.fromMe) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (msg.fromMe) DolphyBlue else DolphySurface
                    ) {
                        Text(msg.text, color = DolphyText, modifier = Modifier.padding(10.dp))
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                label = { Text("رسالة") }
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(onClick = {
                if (input.isNotBlank()) {
                    host?.sendMessage(input)
                    client?.sendMessage(input)
                    input = ""
                }
            }) { Text("إرسال") }
        }
    }
}
