package com.silentcobra.scdolphy.hid

import android.annotation.SuppressLint
import android.bluetooth.*
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.silentcobra.scdolphy.ble.hasBlePermissions
import com.silentcobra.scdolphy.ble.requiredBlePermissions
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold

// Standard USB HID keyboard report descriptor (8-byte boot keyboard report).
private val KEYBOARD_DESCRIPTOR = byteArrayOf(
    0x05, 0x01, 0x09, 0x06, 0xA1.toByte(), 0x01, 0x05, 0x07,
    0x19, 0xE0.toByte(), 0x29, 0xE7.toByte(), 0x15, 0x00, 0x25, 0x01,
    0x75, 0x01, 0x95.toByte(), 0x08, 0x81.toByte(), 0x02, 0x95.toByte(), 0x01,
    0x75, 0x08, 0x81.toByte(), 0x03, 0x95.toByte(), 0x05, 0x75, 0x01,
    0x05, 0x08, 0x19, 0x01, 0x29, 0x05, 0x91.toByte(), 0x02,
    0x95.toByte(), 0x01, 0x75, 0x03, 0x91.toByte(), 0x03, 0x95.toByte(), 0x06,
    0x75, 0x08, 0x15, 0x00, 0x25, 0x65, 0x05, 0x07,
    0x19, 0x00, 0x29, 0x65, 0x81.toByte(), 0x00, 0xC0.toByte()
)

private const val KEY_A = 0x04
private const val KEY_ENTER = 0x28
private const val KEY_SPACE = 0x2C
private const val KEY_BACKSPACE = 0x2A

@SuppressLint("MissingPermission")
@Composable
fun HidScreen() {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(hasBlePermissions(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        hasPermission = r.values.all { it }
    }

    var hidDevice by remember { mutableStateOf<BluetoothHidDevice?>(null) }
    var connectedDevice by remember { mutableStateOf<BluetoothDevice?>(null) }
    var status by remember { mutableStateOf("غير متصل") }

    val adapter = remember { BluetoothAdapter.getDefaultAdapter() }

    DisposableEffect(hasPermission) {
        if (!hasPermission) return@DisposableEffect onDispose { }
        val listener = object : BluetoothProfile.ServiceListener {
            override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
                if (profile == BluetoothProfile.HID_DEVICE) {
                    val hid = proxy as BluetoothHidDevice
                    hidDevice = hid
                    val sdp = BluetoothHidDeviceAppSdpSettings(
                        "SC DOLPHY HID",
                        "Virtual keyboard",
                        "SilentCobra",
                        BluetoothHidDevice.SUBCLASS1_COMBO,
                        KEYBOARD_DESCRIPTOR
                    )
                    val cb = object : BluetoothHidDevice.Callback() {
                        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
                            connectedDevice = if (state == BluetoothProfile.STATE_CONNECTED) device else null
                            status = if (state == BluetoothProfile.STATE_CONNECTED) "متصل بـ ${device?.name}" else "غير متصل"
                        }
                        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
                            status = if (registered) "جاهز — بانتظار الاتصال" else "غير مسجّل"
                        }
                    }
                    hid.registerApp(sdp, null, null, { it.run() }, cb)
                }
            }
            override fun onServiceDisconnected(profile: Int) {
                hidDevice = null
            }
        }
        adapter?.getProfileProxy(context, listener, BluetoothProfile.HID_DEVICE)
        onDispose {
            hidDevice?.let { adapter?.closeProfileProxy(BluetoothProfile.HID_DEVICE, it) }
        }
    }

    fun sendKey(keyCode: Int) {
        val device = connectedDevice ?: return
        val hid = hidDevice ?: return
        val pressReport = byteArrayOf(0, 0, keyCode.toByte(), 0, 0, 0, 0, 0)
        val releaseReport = byteArrayOf(0, 0, 0, 0, 0, 0, 0, 0)
        hid.sendReport(device, 0, pressReport)
        hid.sendReport(device, 0, releaseReport)
    }

    ToolScaffold(title = "HID — لوحة مفاتيح/ماوس") {
        if (!hasPermission) {
            Button(onClick = { launcher.launch(requiredBlePermissions()) }) { Text("منح الأذونات") }
            return@ToolScaffold
        }
        Text("الحالة: $status", color = DolphyText)
        Text(
            "اقرن هذا الجهاز من إعدادات بلوتوث على الكمبيوتر/الهاتف المستهدف باسم \"SC DOLPHY HID\"، ثم استخدم الأزرار أدناه كلوحة مفاتيح افتراضية.",
            color = DolphyText
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { sendKey(KEY_A) }) { Text("A") }
            Button(onClick = { sendKey(KEY_SPACE) }) { Icon(Icons.Default.SpaceBar, contentDescription = "space") }
            Button(onClick = { sendKey(KEY_ENTER) }) { Icon(Icons.Default.KeyboardReturn, contentDescription = "enter") }
            Button(onClick = { sendKey(KEY_BACKSPACE) }) { Icon(Icons.Default.Backspace, contentDescription = "backspace") }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            "ملاحظة: هذه نسخة أساسية لإثبات المفهوم بلوحة مفاتيح محدودة (حرف A، مسافة، إدخال، حذف). يمكن توسيعها لدعم لوحة مفاتيح كاملة ووضع ماوس لاحقًا.",
            color = DolphyText
        )
    }
}
