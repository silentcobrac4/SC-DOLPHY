package com.silentcobra.scdolphy.chat

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import javax.crypto.spec.SecretKeySpec

/** Acts as the BLE peripheral: advertises the chat service and relays encrypted messages
 * written by the connected peer, plus sends outgoing messages via GATT notifications. */
@SuppressLint("MissingPermission")
class ChatHost(private val context: Context, private val key: SecretKeySpec) {
    val messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val statusText = MutableStateFlow("غير نشط")

    private var gattServer: BluetoothGattServer? = null
    private var subscribedDevice: BluetoothDevice? = null
    private var messageChar: BluetoothGattCharacteristic? = null

    private val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter

    fun start() {
        val manager = context.getSystemService(BluetoothManager::class.java)
        val callback = object : BluetoothGattServerCallback() {
            override fun onConnectionStateChange(device: BluetoothDevice, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    statusText.value = "متصل بـ ${device.address}"
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    statusText.value = "بانتظار اتصال..."
                    if (subscribedDevice?.address == device.address) subscribedDevice = null
                }
            }

            override fun onCharacteristicWriteRequest(
                device: BluetoothDevice, requestId: Int, characteristic: BluetoothGattCharacteristic,
                preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray
            ) {
                if (responseNeeded) {
                    gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
                }
                val payload = String(value, Charsets.UTF_8)
                val plain = CryptoUtils.decrypt(payload, key)
                if (plain != null) {
                    messages.value = messages.value + ChatMessage(fromMe = false, text = plain)
                }
            }

            override fun onDescriptorWriteRequest(
                device: BluetoothDevice, requestId: Int, descriptor: BluetoothGattDescriptor,
                preparedWrite: Boolean, responseNeeded: Boolean, offset: Int, value: ByteArray
            ) {
                subscribedDevice = device
                if (responseNeeded) {
                    gattServer?.sendResponse(device, requestId, BluetoothGatt.GATT_SUCCESS, 0, null)
                }
            }
        }

        gattServer = manager?.openGattServer(context, callback)
        val service = BluetoothGattService(ChatGattProfile.SERVICE_UUID, BluetoothGattService.SERVICE_TYPE_PRIMARY)
        val characteristic = BluetoothGattCharacteristic(
            ChatGattProfile.MESSAGE_CHAR_UUID,
            BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_NOTIFY,
            BluetoothGattCharacteristic.PERMISSION_WRITE
        )
        val cccd = BluetoothGattDescriptor(
            ChatGattProfile.CCCD_UUID,
            BluetoothGattDescriptor.PERMISSION_READ or BluetoothGattDescriptor.PERMISSION_WRITE
        )
        characteristic.addDescriptor(cccd)
        service.addCharacteristic(characteristic)
        gattServer?.addService(service)
        messageChar = characteristic

        val advertiser = adapter?.bluetoothLeAdvertiser
        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
            .setConnectable(true)
            .build()
        val data = AdvertiseData.Builder()
            .addServiceUuid(android.os.ParcelUuid(ChatGattProfile.SERVICE_UUID))
            .setIncludeDeviceName(true)
            .build()
        advertiser?.startAdvertising(settings, data, object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
                statusText.value = "يعلن عن الخدمة — بانتظار اتصال..."
            }
            override fun onStartFailure(errorCode: Int) {
                statusText.value = "فشل الإعلان (كود $errorCode)"
            }
        })
    }

    fun sendMessage(text: String) {
        val char = messageChar ?: return
        val device = subscribedDevice ?: return
        val encrypted = CryptoUtils.encrypt(text, key)
        char.value = encrypted.toByteArray(Charsets.UTF_8)
        gattServer?.notifyCharacteristicChanged(device, char, false)
        messages.value = messages.value + ChatMessage(fromMe = true, text = text)
    }

    fun stop() {
        adapter?.bluetoothLeAdvertiser?.stopAdvertising(object : AdvertiseCallback() {})
        gattServer?.close()
    }
}
