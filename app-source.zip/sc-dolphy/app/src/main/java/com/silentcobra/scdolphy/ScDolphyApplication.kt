package com.silentcobra.scdolphy

import android.app.Application

class ScDolphyApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
