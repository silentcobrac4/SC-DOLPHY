package com.silentcobra.scdolphy.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothClass
import android.bluetooth.BluetoothDevice
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold

@SuppressLint("MissingPermission")
@Composable
fun BleAudioScreen() {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(hasBlePermissions(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        hasPermission = results.values.all { it }
    }
    val adapter = remember { BluetoothAdapter.getDefaultAdapter() }
    var paired by remember { mutableStateOf(listOf<BluetoothDevice>()) }
    var connecting by remember { mutableStateOf<String?>(null) }

    ToolScaffold(title = "أجهزة الصوت (بلوتوث)") {
        if (!hasPermission) {
            Button(onClick = { launcher.launch(requiredBlePermissions()) }) {
                Text("منح الأذونات")
            }
            return@ToolScaffold
        }
        Button(onClick = {
            val all = adapter?.bondedDevices?.toList() ?: emptyList()
            paired = all.filter { device ->
                val cls = device.bluetoothClass?.majorDeviceClass
                cls == BluetoothClass.Device.Major.AUDIO_VIDEO
            }
        }) {
            Text("عرض أجهزة الصوت المقترنة")
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text("لإقران جهاز جديد غير مدرج هنا، استخدم إعدادات بلوتوث في النظام ثم عد وأعد العرض.", color = DolphyText)
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(paired) { device ->
                Surface(shape = RoundedCornerShape(12.dp), color = DolphySurface) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(device.name ?: "جهاز صوت", color = DolphyText)
                            Text(device.address, color = DolphyText)
                        }
                        Button(onClick = {
                            connecting = device.address
                            // Connection to A2DP sink is managed by the Android system profile proxy.
                            // We surface the device for the user; actual audio routing uses system Bluetooth settings.
                        }) {
                            Text(if (connecting == device.address) "محدد" else "تحديد")
                        }
                    }
                }
            }
        }
    }
}
