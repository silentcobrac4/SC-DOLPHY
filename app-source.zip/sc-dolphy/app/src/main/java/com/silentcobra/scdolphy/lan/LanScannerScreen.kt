package com.silentcobra.scdolphy.lan

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold
import kotlinx.coroutines.launch

@Composable
fun LanScannerScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val devices = remember { mutableStateMapOf<String, LanDevice>() }
    var scanning by remember { mutableStateOf(false) }

    ToolScaffold(title = "ماسح الشبكة (LAN)") {
        val localInfo = getLocalIpAndPrefix(context)
        if (localInfo == null) {
            Text("اتصل بشبكة Wi-Fi أولاً لاستخدام الماسح.", color = DolphyText)
            return@ToolScaffold
        }
        Text("عنوانك: ${localInfo.first}", color = DolphyText)
        Spacer(modifier = Modifier.height(10.dp))
        Button(
            enabled = !scanning,
            onClick = {
                devices.clear()
                scanning = true
                scope.launch {
                    scanSubnet(localInfo.first) { device ->
                        devices[device.ip] = device
                    }
                    scanning = false
                }
            }
        ) {
            Text(if (scanning) "جاري المسح..." else "ابدأ المسح")
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text("هذا مسح للاكتشاف فقط (ping + جدول ARP) — لا يرسل أي حزم هجومية.", color = DolphyText)
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices.values.sortedBy { it.ip }.toList()) { d ->
                Surface(shape = RoundedCornerShape(12.dp), color = DolphySurface) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(d.ip, color = DolphyText)
                        if (d.mac != null) Text("MAC: ${d.mac}", color = DolphyText)
                        if (d.vendor != null) Text("الشركة المصنّعة: ${d.vendor}", color = DolphyText)
                        if (d.hostname != null) Text("الاسم: ${d.hostname}", color = DolphyText)
                    }
                }
            }
        }
    }
}
