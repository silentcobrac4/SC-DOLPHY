package com.silentcobra.scdolphy.cast

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.mediarouter.app.MediaRouteButton
import com.google.android.gms.cast.framework.CastButtonFactory
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold
import kotlinx.coroutines.launch

@Composable
fun CastScreen() {
    val scope = rememberCoroutineScope()
    val ssdpDevices = remember { mutableStateMapOf<String, SsdpDevice>() }
    var scanning by remember { mutableStateOf(false) }

    ToolScaffold(title = "البث للتلفاز") {
        Text("Chromecast:", color = DolphyText)
        AndroidView(
            factory = { ctx ->
                MediaRouteButton(ctx).apply {
                    CastButtonFactory.setUpMediaRouteButton(ctx, this)
                }
            },
            modifier = Modifier.size(48.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text("DLNA / UPnP:", color = DolphyText)
        Spacer(modifier = Modifier.height(6.dp))
        Button(
            enabled = !scanning,
            onClick = {
                ssdpDevices.clear()
                scanning = true
                scope.launch {
                    discoverSsdpDevices { device -> ssdpDevices[device.usn ?: device.location] = device }
                    scanning = false
                }
            }
        ) {
            Text(if (scanning) "جاري البحث..." else "البحث عن أجهزة DLNA/UPnP")
        }
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(ssdpDevices.values.toList()) { device ->
                Surface(shape = RoundedCornerShape(12.dp), color = DolphySurface) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(device.server ?: "جهاز UPnP", color = DolphyText)
                        Text(device.location, color = DolphyText)
                    }
                }
            }
        }
    }
}
