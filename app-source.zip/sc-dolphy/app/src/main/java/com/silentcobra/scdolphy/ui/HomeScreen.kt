package com.silentcobra.scdolphy.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController

data class DolphyTool(
    val title: String,
    val subtitle: String,
    val route: String,
    val icon: ImageVector
)

data class DolphySection(val header: String, val tools: List<DolphyTool>)

val sections = listOf(
    DolphySection(
        "الأدوات الأصلية الإضافية",
        listOf(
            DolphyTool("محلل البروتوكولات", "Hex view + تصدير CSV/JSON", "analyzer", Icons.Default.Analytics),
            DolphyTool("Dolphy Chat+", "دردشة BLE مشفّرة E2E", "chat_plus", Icons.Default.Chat),
            DolphyTool("الماسح الشبكي الذكي", "خريطة + تصنيف + تنبيهات", "smart_map", Icons.Default.Hub),
        )
    ),
    DolphySection(
        "الأشعة تحت الحمراء",
        listOf(DolphyTool("ريموت IR", "إرسال إشارات للأجهزة", "ir", Icons.Default.SettingsRemote))
    ),
    DolphySection(
        "NFC و QR",
        listOf(
            DolphyTool("NFC", "قراءة/كتابة الوسوم (Mifare/NTAG)", "nfc", Icons.Default.Nfc),
            DolphyTool("QR", "توليد ومسح الأكواد", "qr", Icons.Default.QrCode),
        )
    ),
    DolphySection(
        "Bluetooth & BLE",
        listOf(
            DolphyTool("ماسح BLE", "اكتشاف أجهزة BLE وخدماتها", "ble_scan", Icons.Default.BluetoothSearching),
            DolphyTool("أجهزة الصوت", "ماسح سماعات ومكبرات بلوتوث", "ble_audio", Icons.Default.Headset),
            DolphyTool("HID", "محاكاة لوحة مفاتيح/ماوس", "hid", Icons.Default.Keyboard),
        )
    ),
    DolphySection(
        "الشبكة والبث",
        listOf(
            DolphyTool("ماسح LAN", "اكتشاف أجهزة الشبكة", "lan", Icons.Default.Wifi),
            DolphyTool("البث للتلفاز", "Chromecast / DLNA / UPnP", "cast", Icons.Default.Cast),
        )
    ),
)

@Composable
fun HomeScreen(navController: NavHostController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DolphyBg)
    ) {
        Column(modifier = Modifier.padding(20.dp, 28.dp, 20.dp, 8.dp)) {
            Text(
                "SC DOLPHY",
                color = DolphyCyan,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                "أداة أبحاث البروتوكولات اللاسلكية",
                color = DolphyMuted,
                fontSize = 13.sp
            )
        }
        LazyColumn(
            contentPadding = PaddingValues(16.dp, 4.dp, 16.dp, 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            sections.forEach { section ->
                item {
                    Text(
                        section.header,
                        color = DolphyMuted,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                    )
                }
                items(section.tools) { tool ->
                    ToolCard(tool) { navController.navigate(tool.route) }
                }
            }
        }
    }
}

@Composable
fun ToolCard(tool: DolphyTool, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = DolphySurface,
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = DolphyBg,
                modifier = Modifier.size(44.dp)
            ) {
                Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                    Icon(tool.icon, contentDescription = null, tint = DolphyCyan)
                }
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(tool.title, color = DolphyText, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                Text(tool.subtitle, color = DolphyMuted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronLeft, contentDescription = null, tint = DolphyMuted)
        }
    }
}
