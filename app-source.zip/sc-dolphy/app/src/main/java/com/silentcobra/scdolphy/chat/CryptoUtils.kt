package com.silentcobra.scdolphy.chat

import android.util.Base64
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Passphrase-based end-to-end encryption for Dolphy Chat+.
 * Both peers derive the same AES-256 key from a shared passphrase (set up out-of-band,
 * e.g. spoken aloud between the two people chatting) using PBKDF2, then every BLE message
 * is encrypted with AES-GCM before being written to the GATT characteristic.
 */
object CryptoUtils {
    private const val ITERATIONS = 100_000
    private const val KEY_LENGTH = 256
    // Fixed salt derived from the app's own namespace: acceptable here because the passphrase
    // itself is the actual secret shared between the two chat peers, and the salt's purpose
    // (defeating precomputed rainbow tables across unrelated apps) still holds.
    private val SALT = "SC-DOLPHY-CHATPLUS-SALT".toByteArray()

    fun deriveKey(passphrase: String): SecretKeySpec {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(passphrase.toCharArray(), SALT, ITERATIONS, KEY_LENGTH)
        val keyBytes = factory.generateSecret(spec).encoded
        return SecretKeySpec(keyBytes, "AES")
    }

    fun encrypt(plainText: String, key: SecretKeySpec): String {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        val iv = ByteArray(12).also { SecureRandom().nextBytes(it) }
        cipher.init(Cipher.ENCRYPT_MODE, key, GCMParameterSpec(128, iv))
        val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val combined = iv + cipherText
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    fun decrypt(payload: String, key: SecretKeySpec): String? {
        return try {
            val combined = Base64.decode(payload, Base64.NO_WRAP)
            val iv = combined.copyOfRange(0, 12)
            val cipherText = combined.copyOfRange(12, combined.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            String(cipher.doFinal(cipherText), Charsets.UTF_8)
        } catch (e: Exception) {
            null
        }
    }
}
