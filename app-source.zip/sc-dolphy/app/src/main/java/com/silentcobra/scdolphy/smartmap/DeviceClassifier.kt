package com.silentcobra.scdolphy.smartmap

import com.silentcobra.scdolphy.lan.LanDevice

enum class DeviceType { ROUTER, CAMERA, IOT, MOBILE_OR_PC, UNKNOWN }

/** Best-effort classification using vendor name + hostname heuristics (no fingerprinting of
 * open ports or services — just naming conventions commonly seen on home networks). */
fun classifyDevice(device: LanDevice): DeviceType {
    val vendor = device.vendor?.lowercase() ?: ""
    val hostname = device.hostname?.lowercase() ?: ""
    val combined = "$vendor $hostname"

    return when {
        device.ip.endsWith(".1") || combined.contains("router") || combined.contains("asus") ||
            combined.contains("tp-link") || combined.contains("d-link") -> DeviceType.ROUTER
        combined.contains("camera") || combined.contains("cam") || combined.contains("hikvision") ||
            combined.contains("dahua") -> DeviceType.CAMERA
        combined.contains("nest") || combined.contains("hue") || combined.contains("raspberry") ||
            combined.contains("xiaomi") || combined.contains("iot") -> DeviceType.IOT
        combined.contains("apple") || combined.contains("samsung") || combined.contains("google") ||
            combined.contains("vmware") -> DeviceType.MOBILE_OR_PC
        else -> DeviceType.UNKNOWN
    }
}

fun DeviceType.displayName(): String = when (this) {
    DeviceType.ROUTER -> "راوتر"
    DeviceType.CAMERA -> "كاميرا"
    DeviceType.IOT -> "جهاز منزل ذكي"
    DeviceType.MOBILE_OR_PC -> "هاتف / حاسوب"
    DeviceType.UNKNOWN -> "غير محدد"
}
