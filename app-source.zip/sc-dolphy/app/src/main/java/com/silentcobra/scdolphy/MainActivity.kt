package com.silentcobra.scdolphy

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.silentcobra.scdolphy.analyzer.ProtocolAnalyzerScreen
import com.silentcobra.scdolphy.ble.BleAudioScreen
import com.silentcobra.scdolphy.ble.BleScannerScreen
import com.silentcobra.scdolphy.cast.CastScreen
import com.silentcobra.scdolphy.chat.ChatPlusScreen
import com.silentcobra.scdolphy.hid.HidScreen
import com.silentcobra.scdolphy.ir.IrScreen
import com.silentcobra.scdolphy.lan.LanScannerScreen
import com.silentcobra.scdolphy.nfc.NfcScreen
import com.silentcobra.scdolphy.qr.QrScreen
import com.silentcobra.scdolphy.smartmap.SmartMapScreen
import com.silentcobra.scdolphy.ui.HomeScreen
import com.silentcobra.scdolphy.ui.ScDolphyTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ScDolphyTheme {
                ScDolphyApp()
            }
        }
    }
}

@Composable
fun ScDolphyApp() {
    val navController: NavHostController = rememberNavController()
    Scaffold { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") { HomeScreen(navController) }
            composable("ir") { IrScreen() }
            composable("nfc") { NfcScreen() }
            composable("qr") { QrScreen() }
            composable("ble_scan") { BleScannerScreen() }
            composable("ble_audio") { BleAudioScreen() }
            composable("hid") { HidScreen() }
            composable("lan") { LanScannerScreen() }
            composable("cast") { CastScreen() }
            composable("analyzer") { ProtocolAnalyzerScreen() }
            composable("chat_plus") { ChatPlusScreen() }
            composable("smart_map") { SmartMapScreen() }
        }
    }
}
