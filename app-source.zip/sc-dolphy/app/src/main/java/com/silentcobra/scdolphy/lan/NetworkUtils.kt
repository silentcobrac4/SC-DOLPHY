package com.silentcobra.scdolphy.lan

import android.content.Context
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.File
import java.io.FileReader
import java.net.InetAddress
import java.net.NetworkInterface

data class LanDevice(
    val ip: String,
    val mac: String?,
    val vendor: String?,
    val hostname: String?,
    val isNew: Boolean = false
)

/** A small built-in OUI (MAC prefix -> vendor) table covering common consumer/IoT vendors.
 * Not exhaustive — a full IEEE OUI database is hundreds of thousands of entries and would need
 * to be downloaded; this ships a practical subset for common identification. */
val OUI_TABLE: Map<String, String> = mapOf(
    "F0:18:98" to "Apple", "AC:DE:48" to "Apple", "3C:06:30" to "Apple", "28:F0:76" to "Apple",
    "DC:A6:32" to "Raspberry Pi Foundation", "B8:27:EB" to "Raspberry Pi Foundation",
    "00:1A:11" to "Google", "F4:F5:D8" to "Google", "54:60:09" to "Google",
    "F8:0F:F9" to "Samsung", "5C:0A:5B" to "Samsung", "8C:79:67" to "Samsung",
    "00:17:88" to "Philips (Hue)", "EC:B5:FA" to "Philips",
    "7C:DD:90" to "TP-Link", "50:C7:BF" to "TP-Link", "A4:2B:B0" to "TP-Link",
    "B0:4E:26" to "Xiaomi", "78:11:DC" to "Xiaomi",
    "00:0C:43" to "Ralink/MediaTek", "00:1D:7E" to "MediaTek",
    "18:B4:30" to "Nest Labs",
    "FC:A1:3E" to "Amazon",
    "00:11:32" to "Synology",
    "00:50:56" to "VMware",
    "D4:CA:6D" to "ASUSTek",
    "00:0E:C6" to "D-Link",
    "00:1B:63" to "Apple", "F4:5C:89" to "Apple"
)

fun lookupVendor(mac: String): String? {
    val prefix = mac.uppercase().take(8)
    return OUI_TABLE[prefix]
}

/** Returns this device's IPv4 address and prefix length for the active Wi-Fi interface, if any. */
fun getLocalIpAndPrefix(context: Context): Pair<String, Int>? {
    val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
    val dhcp = wifiManager?.dhcpInfo ?: return null
    if (dhcp.ipAddress == 0) return null
    val ip = intToIp(dhcp.ipAddress)
    val netmask = intToIp(dhcp.netmask)
    val prefix = netmask.split(".").sumOf { Integer.bitCount(it.toInt()) }
    return ip to prefix
}

private fun intToIp(addr: Int): String {
    return "${addr and 0xFF}.${addr shr 8 and 0xFF}.${addr shr 16 and 0xFF}.${addr shr 24 and 0xFF}"
}

/** Reads the kernel ARP table (/proc/net/arp) to map IPs seen on the LAN to their MAC addresses. */
fun readArpTable(): Map<String, String> {
    val result = mutableMapOf<String, String>()
    try {
        val file = File("/proc/net/arp")
        if (!file.exists()) return result
        BufferedReader(FileReader(file)).use { reader ->
            reader.readLine() // header
            reader.forEachLine { line ->
                val parts = line.trim().split(Regex("\\s+"))
                if (parts.size >= 4) {
                    val ip = parts[0]
                    val mac = parts[3]
                    if (mac != "00:00:00:00:00:00") result[ip] = mac
                }
            }
        }
    } catch (_: Exception) { }
    return result
}

/** Sweeps the /24 subnet by attempting a TCP-reachability check on common ports plus ICMP-like
 * isReachable, then cross-references the ARP table for MAC + vendor. Runs on IO dispatcher. */
suspend fun scanSubnet(
    baseIp: String,
    onDeviceFound: (LanDevice) -> Unit
) = withContext(Dispatchers.IO) {
    val parts = baseIp.split(".")
    if (parts.size != 4) return@withContext
    val prefix = "${parts[0]}.${parts[1]}.${parts[2]}"

    val jobs = (1..254).map { host ->
        async {
            val ip = "$prefix.$host"
            try {
                val addr = InetAddress.getByName(ip)
                val reachable = addr.isReachable(300)
                if (reachable) {
                    val arp = readArpTable()
                    val mac = arp[ip]
                    val vendor = mac?.let { lookupVendor(it) }
                    val hostname = try { addr.canonicalHostName.takeIf { it != ip } } catch (_: Exception) { null }
                    onDeviceFound(LanDevice(ip, mac, vendor, hostname))
                }
            } catch (_: Exception) { }
        }
    }
    jobs.awaitAll()
}
