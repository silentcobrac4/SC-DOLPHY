package com.silentcobra.scdolphy.cast

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

data class SsdpDevice(val location: String, val server: String?, val usn: String?)

/** Sends an SSDP M-SEARCH multicast and collects DLNA/UPnP device responses for ~3 seconds. */
suspend fun discoverSsdpDevices(onFound: (SsdpDevice) -> Unit) = withContext(Dispatchers.IO) {
    val searchMessage = "M-SEARCH * HTTP/1.1\r\n" +
        "HOST: 239.255.255.250:1900\r\n" +
        "MAN: \"ssdp:discover\"\r\n" +
        "MX: 2\r\n" +
        "ST: ssdp:all\r\n\r\n"

    var socket: DatagramSocket? = null
    try {
        socket = DatagramSocket()
        socket.soTimeout = 500
        val group = InetAddress.getByName("239.255.255.250")
        val sendPacket = DatagramPacket(searchMessage.toByteArray(), searchMessage.length, group, 1900)
        socket.send(sendPacket)

        withTimeoutOrNull(3000) {
            val buffer = ByteArray(2048)
            while (true) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    socket.receive(packet)
                    val response = String(packet.data, 0, packet.length)
                    val location = Regex("LOCATION:\\s*(.+)", RegexOption.IGNORE_CASE)
                        .find(response)?.groupValues?.get(1)?.trim()
                    val server = Regex("SERVER:\\s*(.+)", RegexOption.IGNORE_CASE)
                        .find(response)?.groupValues?.get(1)?.trim()
                    val usn = Regex("USN:\\s*(.+)", RegexOption.IGNORE_CASE)
                        .find(response)?.groupValues?.get(1)?.trim()
                    if (location != null) onFound(SsdpDevice(location, server, usn))
                } catch (_: Exception) {
                    // timeout on this read iteration; keep looping until the outer timeout fires
                }
            }
        }
    } catch (_: Exception) {
    } finally {
        socket?.close()
    }
}
