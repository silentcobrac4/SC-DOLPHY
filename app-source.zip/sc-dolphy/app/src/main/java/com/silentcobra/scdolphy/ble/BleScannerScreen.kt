package com.silentcobra.scdolphy.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.silentcobra.scdolphy.data.CaptureStore
import com.silentcobra.scdolphy.data.CapturedRecord
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold

data class BleDeviceInfo(
    val name: String,
    val address: String,
    val rssi: Int,
    val serviceUuids: List<String>
)

@SuppressLint("MissingPermission")
@Composable
fun BleScannerScreen() {
    val context = LocalContext.current
    var hasPermission by remember { mutableStateOf(hasBlePermissions(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
        hasPermission = results.values.all { it }
    }

    val devices = remember { mutableStateMapOf<String, BleDeviceInfo>() }
    var scanning by remember { mutableStateOf(false) }

    val adapter = remember { BluetoothAdapter.getDefaultAdapter() }
    val scanner = remember { adapter?.bluetoothLeScanner }

    val callback = remember {
        object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val device: BluetoothDevice = result.device
                val info = BleDeviceInfo(
                    name = device.name ?: "جهاز غير معروف",
                    address = device.address,
                    rssi = result.rssi,
                    serviceUuids = result.scanRecord?.serviceUuids?.map { it.toString() } ?: emptyList()
                )
                devices[device.address] = info
                CaptureStore.add(
                    CapturedRecord(
                        source = "BLE",
                        label = info.name,
                        rawBytes = result.scanRecord?.bytes ?: ByteArray(0),
                        fields = mapOf("address" to info.address, "rssi" to info.rssi.toString())
                    )
                )
            }
        }
    }

    DisposableEffect(scanning) {
        if (scanning && hasPermission && scanner != null) {
            scanner.startScan(callback)
        }
        onDispose {
            if (hasPermission) scanner?.stopScan(callback)
        }
    }

    ToolScaffold(title = "ماسح BLE") {
        if (!hasPermission) {
            Button(onClick = { launcher.launch(requiredBlePermissions()) }) {
                Text("منح الأذونات")
            }
            return@ToolScaffold
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { scanning = !scanning }) {
                Text(if (scanning) "إيقاف المسح" else "بدء المسح")
            }
            OutlinedButton(onClick = { devices.clear() }) { Text("مسح القائمة") }
        }
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices.values.sortedByDescending { it.rssi }.toList()) { d ->
                Surface(shape = RoundedCornerShape(12.dp), color = DolphySurface) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(d.name, color = DolphyText)
                        Text("${d.address} · RSSI: ${d.rssi} dBm", color = DolphyText)
                        if (d.serviceUuids.isNotEmpty()) {
                            Text("Services: ${d.serviceUuids.joinToString()}", color = DolphyText)
                        }
                    }
                }
            }
        }
    }
}
