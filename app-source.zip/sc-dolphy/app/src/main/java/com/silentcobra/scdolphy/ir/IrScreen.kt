package com.silentcobra.scdolphy.ir

import android.content.Context
import android.hardware.ConsumerIrManager
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold

/** A remote code: carrier frequency (Hz) + on/off pulse pattern in microseconds. */
data class IrCode(val name: String, val frequencyHz: Int, val pattern: IntArray)

// A small built-in database of common power-toggle codes for popular brands (NEC protocol).
// Real-world remotes vary by exact model; this covers widely-used NEC "power" codes as a starting set.
val IR_DATABASE = listOf(
    IrCode("TV - Samsung (Power)", 38000, necPattern(0x07, 0x07, 0x02)),
    IrCode("TV - LG (Power)", 38000, necPattern(0x04, 0x04, 0x08)),
    IrCode("TV - Sony (Power)", 40000, necPattern(0x01, 0x00, 0x15)),
    IrCode("AC - Generic (Power)", 38000, necPattern(0x00, 0xFF.toInt(), 0x01)),
    IrCode("Projector - Generic (Power)", 38000, necPattern(0x20, 0xDF.toInt(), 0x0C)),
)

/** Builds a standard NEC-protocol pulse train for the given address/command bytes. */
fun necPattern(address: Int, addressInv: Int, command: Int): IntArray {
    val commandInv = command.inv() and 0xFF
    val bits = mutableListOf<Int>()
    val pulses = mutableListOf(9000, 4500) // leading burst + space
    val data = listOf(address, addressInv, command, commandInv)
    data.forEach { byte ->
        for (i in 0 until 8) {
            val bit = (byte shr i) and 1
            pulses.add(560)
            pulses.add(if (bit == 1) 1690 else 560)
        }
    }
    pulses.add(560) // final mark
    return pulses.toIntArray()
}

@Composable
fun IrScreen() {
    val context = LocalContext.current
    val irManager = remember {
        context.getSystemService(Context.CONSUMER_IR_SERVICE) as? ConsumerIrManager
    }
    val hasIr = irManager?.hasIrEmitter() == true
    var status by remember { mutableStateOf("") }

    ToolScaffold(title = "ريموت IR") {
        if (!hasIr) {
            Text(
                "هذا الجهاز لا يحتوي على مرسل IR فعلي (ConsumerIrManager). الميزة تتطلب عتادًا مزودًا بباعث أشعة تحت حمراء.",
                color = DolphyText
            )
            return@ToolScaffold
        }
        Text("اختر إشارة لإرسالها إلى جهازك:", color = DolphyText)
        Spacer(modifier = Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(IR_DATABASE) { code ->
                Surface(shape = RoundedCornerShape(12.dp), color = DolphySurface) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(code.name, color = DolphyText)
                        Button(onClick = {
                            try {
                                irManager?.transmit(code.frequencyHz, code.pattern)
                                status = "تم إرسال: ${code.name}"
                            } catch (e: Exception) {
                                status = "فشل الإرسال: ${e.message}"
                            }
                        }) {
                            Text("إرسال")
                        }
                    }
                }
            }
        }
        if (status.isNotEmpty()) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(status, color = DolphyText)
        }
    }
}
