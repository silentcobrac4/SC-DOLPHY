package com.silentcobra.scdolphy.chat

import java.util.UUID

object ChatGattProfile {
    val SERVICE_UUID: UUID = UUID.fromString("7a2e9c10-0001-4a6f-8b9a-5c1d2e3f4a5b")
    val MESSAGE_CHAR_UUID: UUID = UUID.fromString("7a2e9c10-0002-4a6f-8b9a-5c1d2e3f4a5b")
    val CCCD_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
}

data class ChatMessage(val fromMe: Boolean, val text: String, val timestamp: Long = System.currentTimeMillis())
