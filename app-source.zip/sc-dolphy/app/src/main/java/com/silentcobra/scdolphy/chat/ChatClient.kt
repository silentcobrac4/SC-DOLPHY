package com.silentcobra.scdolphy.chat

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.ParcelUuid
import kotlinx.coroutines.flow.MutableStateFlow
import javax.crypto.spec.SecretKeySpec

/** Acts as the BLE central: scans for a Dolphy Chat+ host, connects, subscribes to notifications,
 * and encrypts/decrypts messages with the shared passphrase-derived key. */
@SuppressLint("MissingPermission")
class ChatClient(private val context: Context, private val key: SecretKeySpec) {
    val messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val statusText = MutableStateFlow("يبحث عن مضيف...")

    private var gatt: BluetoothGatt? = null
    private var messageChar: BluetoothGattCharacteristic? = null
    private val adapter = context.getSystemService(BluetoothManager::class.java)?.adapter

    fun start() {
        val scanner = adapter?.bluetoothLeScanner
        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(ChatGattProfile.SERVICE_UUID))
            .build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()

        val scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                scanner?.stopScan(this)
                statusText.value = "تم العثور على مضيف، جاري الاتصال..."
                connectTo(result.device)
            }
        }
        scanner?.startScan(listOf(filter), settings, scanCallback)
    }

    private fun connectTo(device: BluetoothDevice) {
        gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    statusText.value = "متصل، جاري اكتشاف الخدمات..."
                    g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    statusText.value = "تم قطع الاتصال"
                }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                val service = g.getService(ChatGattProfile.SERVICE_UUID)
                val char = service?.getCharacteristic(ChatGattProfile.MESSAGE_CHAR_UUID)
                messageChar = char
                if (char != null) {
                    g.setCharacteristicNotification(char, true)
                    val cccd = char.getDescriptor(ChatGattProfile.CCCD_UUID)
                    cccd?.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    cccd?.let { g.writeDescriptor(it) }
                    statusText.value = "جاهز للدردشة"
                }
            }

            override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                val payload = String(characteristic.value, Charsets.UTF_8)
                val plain = CryptoUtils.decrypt(payload, key)
                if (plain != null) {
                    messages.value = messages.value + ChatMessage(fromMe = false, text = plain)
                }
            }
        })
    }

    fun sendMessage(text: String) {
        val char = messageChar ?: return
        val encrypted = CryptoUtils.encrypt(text, key)
        char.value = encrypted.toByteArray(Charsets.UTF_8)
        char.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        gatt?.writeCharacteristic(char)
        messages.value = messages.value + ChatMessage(fromMe = true, text = text)
    }

    fun stop() {
        gatt?.disconnect()
        gatt?.close()
    }
}
