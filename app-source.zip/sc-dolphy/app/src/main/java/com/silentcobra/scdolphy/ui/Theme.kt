package com.silentcobra.scdolphy.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DolphyBg = Color(0xFF060B14)
val DolphySurface = Color(0xFF0E1826)
val DolphyCyan = Color(0xFF2FD2FF)
val DolphyBlue = Color(0xFF1E66F5)
val DolphyText = Color(0xFFEAF6FF)
val DolphyMuted = Color(0xFF7E95AE)

private val DolphyColors = darkColorScheme(
    primary = DolphyCyan,
    secondary = DolphyBlue,
    background = DolphyBg,
    surface = DolphySurface,
    onPrimary = DolphyBg,
    onSecondary = DolphyText,
    onBackground = DolphyText,
    onSurface = DolphyText,
)

@Composable
fun ScDolphyTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DolphyColors,
        content = content
    )
}
