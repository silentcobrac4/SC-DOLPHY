package com.silentcobra.scdolphy.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.*

/**
 * A single captured packet/record from any module (BLE advertisement, NFC tag read, etc).
 * Used by the Protocol Analyzer to show a hex view and allow CSV/JSON export.
 */
data class CapturedRecord(
    val timestamp: Long = System.currentTimeMillis(),
    val source: String,       // e.g. "BLE", "NFC"
    val label: String,        // e.g. device name / tag type
    val rawBytes: ByteArray,
    val fields: Map<String, String> = emptyMap()
) {
    val timeString: String
        get() = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date(timestamp))

    val hex: String
        get() = rawBytes.joinToString(" ") { String.format("%02X", it) }
}

/** Simple in-memory, app-lifetime store (not persisted). Shared across modules via singleton object. */
object CaptureStore {
    private const val MAX_RECORDS = 500
    private val _records = MutableStateFlow<List<CapturedRecord>>(emptyList())
    val records = _records.asStateFlow()

    fun add(record: CapturedRecord) {
        val updated = (_records.value + record).takeLast(MAX_RECORDS)
        _records.value = updated
    }

    fun clear() {
        _records.value = emptyList()
    }

    fun toCsv(): String {
        val sb = StringBuilder("timestamp,source,label,hex\n")
        _records.value.forEach {
            sb.append("${it.timestamp},${it.source},\"${it.label}\",${it.hex}\n")
        }
        return sb.toString()
    }

    fun toJson(): String {
        val sb = StringBuilder("[\n")
        _records.value.forEachIndexed { index, r ->
            sb.append("  {\"timestamp\": ${r.timestamp}, \"source\": \"${r.source}\", ")
            sb.append("\"label\": \"${r.label}\", \"hex\": \"${r.hex}\"}")
            if (index != _records.value.lastIndex) sb.append(",")
            sb.append("\n")
        }
        sb.append("]")
        return sb.toString()
    }
}
