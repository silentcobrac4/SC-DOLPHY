package com.silentcobra.scdolphy

import android.app.Application

class ScDolphyApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
