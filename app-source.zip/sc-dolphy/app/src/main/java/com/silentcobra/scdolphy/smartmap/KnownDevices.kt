package com.silentcobra.scdolphy.smartmap

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

private const val PREFS = "sc_dolphy_known_devices"
private const val CHANNEL_ID = "smart_map_alerts"

fun getKnownMacs(context: Context): Set<String> {
    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    return prefs.getStringSet("macs", emptySet()) ?: emptySet()
}

fun saveKnownMacs(context: Context, macs: Set<String>) {
    val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    prefs.edit().putStringSet("macs", macs).apply()
}

fun ensureNotificationChannel(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val channel = NotificationChannel(
            CHANNEL_ID, "تنبيهات الشبكة الذكية", NotificationManager.IMPORTANCE_DEFAULT
        )
        val manager = context.getSystemService(NotificationManager::class.java)
        manager?.createNotificationChannel(channel)
    }
}

fun notifyNewDevice(context: Context, ip: String, vendor: String?) {
    ensureNotificationChannel(context)
    val notification = NotificationCompat.Builder(context, CHANNEL_ID)
        .setSmallIcon(android.R.drawable.stat_sys_warning)
        .setContentTitle("جهاز جديد على شبكتك")
        .setContentText("$ip" + (vendor?.let { " — $it" } ?: ""))
        .setAutoCancel(true)
        .build()
    try {
        NotificationManagerCompat.from(context).notify(ip.hashCode(), notification)
    } catch (_: SecurityException) {
        // POST_NOTIFICATIONS not granted; silently skip, the in-app list still shows it
    }
}
