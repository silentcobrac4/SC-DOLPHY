package com.silentcobra.scdolphy.nfc

import android.app.Activity
import android.nfc.NdefMessage
import android.nfc.NdefRecord
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.nfc.tech.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.silentcobra.scdolphy.data.CaptureStore
import com.silentcobra.scdolphy.data.CapturedRecord
import com.silentcobra.scdolphy.ui.DolphySurface
import com.silentcobra.scdolphy.ui.DolphyText
import com.silentcobra.scdolphy.ui.ToolScaffold
import java.nio.charset.Charset

private fun bytesToHex(bytes: ByteArray) = bytes.joinToString(" ") { String.format("%02X", it) }

/** Identifies the underlying chip family from the Tag's tech list, giving friendlier detail than raw tech names. */
private fun describeTag(tag: Tag): Pair<String, List<String>> {
    val techs = tag.techList.toList()
    val details = mutableListOf<String>()
    var family = "NFC Tag غير معروف"

    if (techs.any { it.endsWith("MifareClassic") }) {
        family = "MIFARE Classic"
        try {
            val mc = MifareClassic.get(tag)
            details += "النوع: ${typeName(mc.type)}"
            details += "عدد القطاعات: ${mc.sectorCount}"
            details += "الحجم: ${mc.size} بايت"
        } catch (_: Exception) {}
    } else if (techs.any { it.endsWith("MifareUltralight") }) {
        family = "NTAG / MIFARE Ultralight"
        try {
            val mu = MifareUltralight.get(tag)
            details += "النوع: ${if (mu.type == MifareUltralight.TYPE_ULTRALIGHT_C) "Ultralight C" else "Ultralight"}"
        } catch (_: Exception) {}
    } else if (techs.any { it.endsWith("NfcF") }) {
        family = "FeliCa (NFC-F)"
        try {
            val f = NfcF.get(tag)
            details += "System Code: ${bytesToHex(f.systemCode)}"
            details += "Manufacturer: ${bytesToHex(f.manufacturer)}"
        } catch (_: Exception) {}
    } else if (techs.any { it.endsWith("NfcA") }) {
        family = "NFC-A (ISO14443-3A)"
    } else if (techs.any { it.endsWith("NfcB") }) {
        family = "NFC-B (ISO14443-3B)"
    } else if (techs.any { it.endsWith("NfcV") }) {
        family = "NFC-V (ISO15693)"
    }
    return family to details
}

private fun typeName(type: Int): String = when (type) {
    MifareClassic.TYPE_CLASSIC -> "Classic"
    MifareClassic.TYPE_PLUS -> "Plus"
    MifareClassic.TYPE_PRO -> "Pro"
    else -> "Unknown"
}

@Composable
fun NfcScreen() {
    val context = LocalContext.current
    val activity = context as? Activity
    val adapter = remember { NfcAdapter.getDefaultAdapter(context) }

    var lastTag by remember { mutableStateOf<Tag?>(null) }
    var family by remember { mutableStateOf("") }
    var details by remember { mutableStateOf(listOf<String>()) }
    var uidHex by remember { mutableStateOf("") }
    var ndefText by remember { mutableStateOf("") }
    var writeText by remember { mutableStateOf("") }
    var writeStatus by remember { mutableStateOf("") }

    DisposableEffect(activity) {
        val callback = NfcAdapter.ReaderCallback { tag ->
            lastTag = tag
            uidHex = bytesToHex(tag.id)
            val (fam, det) = describeTag(tag)
            family = fam
            details = det

            // Try reading NDEF content if present
            val ndef = Ndef.get(tag)
            val message = try {
                ndef?.let {
                    it.connect()
                    val m = it.cachedNdefMessage ?: it.ndefMessage
                    it.close()
                    m
                }
            } catch (_: Exception) { null }

            val textPayload = message?.records?.firstOrNull()?.let { record ->
                try {
                    val payload = record.payload
                    val langLen = payload[0].toInt() and 0x3F
                    String(payload, 1 + langLen, payload.size - 1 - langLen, Charset.forName("UTF-8"))
                } catch (_: Exception) { null }
            }
            ndefText = textPayload ?: ""

            CaptureStore.add(
                CapturedRecord(
                    source = "NFC",
                    label = family,
                    rawBytes = tag.id,
                    fields = mapOf("UID" to uidHex, "Techs" to tag.techList.joinToString())
                )
            )
        }

        if (activity != null && adapter != null) {
            adapter.enableReaderMode(
                activity,
                callback,
                NfcAdapter.FLAG_READER_NFC_A or NfcAdapter.FLAG_READER_NFC_B or
                    NfcAdapter.FLAG_READER_NFC_F or NfcAdapter.FLAG_READER_NFC_V or
                    NfcAdapter.FLAG_READER_SKIP_NDEF_CHECK,
                null
            )
        }
        onDispose {
            if (activity != null) adapter?.disableReaderMode(activity)
        }
    }

    ToolScaffold(title = "NFC") {
        if (adapter == null) {
            Text("هذا الجهاز لا يدعم NFC.", color = DolphyText)
            return@ToolScaffold
        }
        if (!adapter.isEnabled) {
            Text("فعّل NFC من إعدادات الجهاز ثم عد إلى هذه الشاشة.", color = DolphyText)
            return@ToolScaffold
        }
        Text("قرّب الوسم (Tag) من ظهر الجهاز...", color = DolphyText)
        Spacer(modifier = Modifier.height(12.dp))

        if (lastTag != null) {
            Surface(shape = RoundedCornerShape(12.dp), color = DolphySurface) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("النوع: $family", color = DolphyText)
                    Text("UID: $uidHex", color = DolphyText)
                    details.forEach { Text(it, color = DolphyText) }
                    if (ndefText.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("محتوى NDEF (نص): $ndefText", color = DolphyText)
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
            Text("كتابة نص NDEF على الوسم:", color = DolphyText)
            OutlinedTextField(
                value = writeText,
                onValueChange = { writeText = it },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            Button(onClick = {
                val tag = lastTag
                if (tag == null) {
                    writeStatus = "لا يوجد وسم بالقرب من الجهاز."
                    return@Button
                }
                try {
                    val ndef = Ndef.get(tag)
                    val record = NdefRecord.createTextRecord("en", writeText)
                    val message = NdefMessage(arrayOf(record))
                    if (ndef != null) {
                        ndef.connect()
                        if (!ndef.isWritable) {
                            writeStatus = "الوسم للقراءة فقط."
                        } else if (ndef.maxSize < message.toByteArray().size) {
                            writeStatus = "الرسالة أكبر من سعة الوسم."
                        } else {
                            ndef.writeNdefMessage(message)
                            writeStatus = "تمت الكتابة بنجاح."
                        }
                        ndef.close()
                    } else {
                        val formatable = NdefFormatable.get(tag)
                        if (formatable != null) {
                            formatable.connect()
                            formatable.format(message)
                            formatable.close()
                            writeStatus = "تمت فرمتة الوسم والكتابة."
                        } else {
                            writeStatus = "هذا الوسم لا يدعم NDEF."
                        }
                    }
                } catch (e: Exception) {
                    writeStatus = "فشل: ${e.message}"
                }
            }) {
                Text("كتابة")
            }
            if (writeStatus.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(writeStatus, color = DolphyText)
            }
        }
    }
}
