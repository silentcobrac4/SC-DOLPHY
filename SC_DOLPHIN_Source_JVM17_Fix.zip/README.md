# SC DOLPHIN — Android project package

This is a buildable Android project candidate with:
- BLE nearby scan
- QR code generation
- NFC tag detection and NDEF text writing (tap-to-write workflow)
- Consumer IR NEC transmitter (requires a compatible IR emitter and correct code)
- Local IPv4 /24 host discovery (limited to the connected LAN)

Important: This package is **not a verified final implementation of every feature originally requested**. BLE chat, QR camera scanning, Bluetooth HID keyboard/mouse, and Google Cast are not implemented here. Hardware functions require compatible Android hardware, permissions, and real-device testing. Do not describe this package as the complete SC DOLPHIN release.

## Build
Open with Android Studio or run `gradle assembleDebug` with Android SDK installed.

## GitHub Actions
Place `SC_DOLPHIN_Source.zip` in repository root and the workflow at:
`.github/workflows/build.yml`

The workflow extracts the ZIP and builds `app-debug.apk`.
