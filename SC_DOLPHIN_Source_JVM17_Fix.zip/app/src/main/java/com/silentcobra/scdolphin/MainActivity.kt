package com.silentcobra.scdolphin

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.hardware.ConsumerIrManager
import android.nfc.*
import android.nfc.tech.Ndef
import android.os.*
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.Socket
import java.util.Collections
import java.util.UUID
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import com.google.zxing.WriterException

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var logView: TextView
    private lateinit var input: EditText
    private val executor = Executors.newFixedThreadPool(32)
    private var bleScanner: BluetoothLeScanner? = null
    private var scanCallback: ScanCallback? = null
    private var nfcAdapter: NfcAdapter? = null
    private var nfcPendingIntent: PendingIntent? = null
    private var nfcWriteText = "SC DOLPHIN NFC test"
    private val found = Collections.synchronizedSet(mutableSetOf<String>())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        buildUi()
        handleNfcIntent(intent)
        requestBluetoothPermissions()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 24)
            setBackgroundColor(Color.rgb(12, 18, 28))
        }
        scroll.addView(root)
        setContentView(scroll)
        val title = TextView(this).apply {
            text = "SC DOLPHIN"
            textSize = 28f
            setTextColor(Color.rgb(0, 220, 190))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 16)
        }
        root.addView(title)
        input = EditText(this).apply {
            hint = "Text / QR / NFC / IR values"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            setSingleLine(false)
            setPadding(14, 12, 14, 12)
            setBackgroundColor(Color.rgb(32, 42, 55))
        }
        root.addView(input)
        addButton("Bluetooth / BLE scan") { startBleScan() }
        addButton("Generate QR code") { generateQr(input.text.toString()) }
        addButton("NFC read / write: tap a tag") { nfcWriteText = input.text.toString().ifBlank { "SC DOLPHIN" }; log("Ready: tap an NFC tag. NDEF write text set.") }
        addButton("Send IR (NEC hex: address,command)") { sendNec(input.text.toString()) }
        addButton("Scan local /24 network") { scanLocalNetwork() }
        addButton("Stop BLE scan") { stopBleScan() }
        logView = TextView(this).apply {
            text = "Ready. Features require compatible phone hardware and permissions."
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(0, 20, 0, 16)
        }
        root.addView(logView)
    }

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        root.addView(b)
    }

    private fun log(s: String) {
        runOnUiThread { logView.append("\n$s") }
    }

    private fun requestBluetoothPermissions() {
        if (Build.VERSION.SDK_INT >= 31) {
            val missing = arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE)
                .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
            if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 11)
        } else if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 11)
        }
    }

    private fun startBleScan() {
        try {
            val manager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
            val adapter = manager.adapter ?: return log("Bluetooth unavailable")
            if (!adapter.isEnabled) return log("Turn Bluetooth on first")
            bleScanner = adapter.bluetoothLeScanner
            found.clear()
            scanCallback = object : ScanCallback() {
                override fun onScanResult(type: Int, result: ScanResult) {
                    val name = result.device.name ?: result.scanRecord?.deviceName ?: "Unnamed BLE"
                    val row = "$name | ${result.device.address} | RSSI ${result.rssi}"
                    if (found.add(row)) log(row)
                }
                override fun onScanFailed(errorCode: Int) { log("BLE scan error: $errorCode") }
            }
            bleScanner?.startScan(scanCallback)
            log("BLE scan started (nearby devices only)")
        } catch (e: SecurityException) { log("Permission required: ${e.message}") }
        catch (e: Exception) { log("BLE error: ${e.message}") }
    }

    private fun stopBleScan() {
        try { scanCallback?.let { bleScanner?.stopScan(it) }; scanCallback = null; log("BLE scan stopped") }
        catch (e: Exception) { log("Stop scan: ${e.message}") }
    }

    private fun generateQr(text: String) {
        if (text.isBlank()) return log("Enter text to create QR")
        try {
            val matrix = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 640, 640)
            val bmp = Bitmap.createBitmap(640, 640, Bitmap.Config.ARGB_8888)
            for (x in 0 until 640) for (y in 0 until 640) bmp.setPixel(x, y, if (matrix[x, y]) Color.BLACK else Color.WHITE)
            val image = ImageView(this).apply { setImageBitmap(bmp); adjustViewBounds = true; setPadding(0, 12, 0, 12) }
            root.addView(image, 2)
            log("QR generated. Scanner support can be added with camera permission/library.")
        } catch (e: WriterException) { log("QR error: ${e.message}") }
    }

    private fun sendNec(raw: String) {
        val ir = getSystemService(CONSUMER_IR_SERVICE) as? ConsumerIrManager
            ?: return log("This phone has no IR transmitter")
        if (!ir.hasIrEmitter()) return log("No IR emitter detected")
        val parts = raw.split(",", " ").filter { it.isNotBlank() }
        if (parts.size < 2) return log("Enter NEC address,command as hex, e.g. 00,10")
        try {
            val address = parts[0].trim().removePrefix("0x").toInt(16) and 0xff
            val command = parts[1].trim().removePrefix("0x").toInt(16) and 0xff
            val data = intArrayOf(address, address xor 0xff, command, command xor 0xff)
            val pulses = ArrayList<Int>()
            pulses.add(9000); pulses.add(4500)
            for (byte in data) for (bit in 0..7) {
                pulses.add(560)
                pulses.add(if ((byte shr bit) and 1 == 1) 1690 else 560)
            }
            pulses.add(560)
            ir.transmit(38000, pulses.toIntArray())
            log("NEC IR transmitted. Device code compatibility depends on the target.")
        } catch (e: Exception) { log("IR error: ${e.message}") }
    }

    private fun scanLocalNetwork() {
        log("Starting local subnet discovery (only your connected LAN)...")
        executor.execute {
            try {
                val address = localIpv4() ?: return@execute log("Could not determine local IPv4")
                val bytes = address.address
                val prefix = "${bytes[0].toInt() and 255}.${bytes[1].toInt() and 255}.${bytes[2].toInt() and 255}"
                val count = AtomicInteger(0)
                for (i in 1..254) {
                    val host = "$prefix.$i"
                    executor.execute {
                        try {
                            val inet = InetAddress.getByName(host)
                            val ports = intArrayOf(80, 443, 554, 8008, 8080, 1900)
                            var open = false
                            for (port in ports) {
                                try { Socket().use { it.connect(java.net.InetSocketAddress(inet, port), 180); open = true } }
                                catch (_: Exception) {}
                            }
                            if (open || inet.isReachable(250)) log("LAN host: $host")
                        } catch (_: Exception) {}
                        if (count.incrementAndGet() == 254) log("LAN scan complete")
                    }
                }
            } catch (e: Exception) { log("LAN scan error: ${e.message}") }
        }
    }

    private fun localIpv4(): Inet4Address? {
        val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
        for (ni in Collections.list(interfaces)) {
            if (!ni.isUp || ni.isLoopback) continue
            for (a in Collections.list(ni.inetAddresses)) if (a is Inet4Address && !a.isLoopbackAddress) return a
        }
        return null
    }

    override fun onResume() {
        super.onResume()
        val adapter = nfcAdapter ?: return
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        nfcPendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_MUTABLE)
        try { adapter.enableForegroundDispatch(this, nfcPendingIntent, null, null) } catch (_: Exception) {}
    }

    override fun onPause() {
        try { nfcAdapter?.disableForegroundDispatch(this) } catch (_: Exception) {}
        super.onPause()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleNfcIntent(intent)
    }

    private fun handleNfcIntent(intent: Intent?) {
        if (intent == null) return
        val tag = intent.getParcelableExtra<Tag>(NfcAdapter.EXTRA_TAG) ?: return
        log("NFC tag detected")
        executor.execute {
            try {
                val ndef = Ndef.get(tag)
                if (ndef != null) {
                    ndef.connect()
                    val msg = NdefMessage(arrayOf(NdefRecord.createTextRecord("en", nfcWriteText)))
                    if (ndef.isWritable && ndef.maxSize >= msg.toByteArray().size) {
                        ndef.writeNdefMessage(msg)
                        log("NDEF text written to tag")
                    } else {
                        val existing = ndef.cachedNdefMessage
                        log("Tag not writable or insufficient space. Existing records: ${existing?.records?.size ?: 0}")
                    }
                    ndef.close()
                } else log("Tag detected but not NDEF formatted / supported")
            } catch (e: Exception) { log("NFC error: ${e.message}") }
        }
    }

    override fun onDestroy() {
        stopBleScan()
        executor.shutdownNow()
        super.onDestroy()
    }
}
