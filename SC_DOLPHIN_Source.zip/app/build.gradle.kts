plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.silentcobra.scdolphin"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.silentcobra.scdolphin"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}
dependencies {
    implementation("com.google.zxing:core:3.5.3")
}
